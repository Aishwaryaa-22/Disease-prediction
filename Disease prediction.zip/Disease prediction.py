#!/usr/bin/env python
# coding: utf-8

# In[5]:


pip install pandasql


# In[6]:


# Importing the libraries 

import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns

# Ignore harmless warnings 

import warnings 
warnings.filterwarnings("ignore")

# Set to display all the columns in dataset

pd.set_option("display.max_columns", None)

# Import psql to run queries 

import pandasql as psql


# In[10]:


# load the disease dataset (B='benign'and M='maglinant')

disease= pd.read_csv(r"D:\disease_prediction_csv.csv",header=0)

# Copy the file to back-up file
disease_BK = disease.copy()

# Display first 5 records
disease.head()


# In[11]:


disease.info()


# In[12]:


disease.nunique()


# In[14]:


disease['Cholesterol'].value_counts()


# In[15]:


#use labelencoder to handle categorical data
from sklearn.preprocessing import LabelEncoder
LE=LabelEncoder()
disease['Cholesterol']=LE.fit_transform(disease[['Cholesterol']])


# In[16]:


disease['Cholesterol'].value_counts()


# In[17]:


# Displaying Duplicate values with in dataset
disease_dup=disease[disease.duplicated(keep='last')]

# Display the duplicate records

disease_dup


# In[18]:


disease.isnull().sum()


# In[19]:


del disease['Stress Level']
disease.head()


# In[20]:


disease.describe()


# In[21]:


# Identify the independent and Target (dependent) variables

IndepVar = []
for col in disease.columns:
    if col != 'Cholesterol':
        IndepVar.append(col)

TargetVar = 'Cholesterol'

x =disease[IndepVar]
y =disease[TargetVar]


# In[22]:


# Split the data into train and test (random sampling)

from sklearn.model_selection import train_test_split 

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42)

# Display the shape for train & test data

x_train.shape, x_test.shape, y_train.shape, y_test.shape


# In[27]:


df = pd.DataFrame(disease)


# In[71]:


df = df.dropna()


# In[72]:


df = df.dropna(axis=1)


# In[73]:


df = df.dropna(subset=['bmi', 'BloodPressure'])


# In[74]:


# Convert categorical variables using LabelEncoder
label_encoder = LabelEncoder()
df['gender'] = label_encoder.fit_transform(df['gender'])
df['Family History'] = label_encoder.fit_transform(df['Family History'])
df['Diabetes'] = label_encoder.fit_transform(df['Diabetes'])

# Split data into features (X) and target variable (y)
X = df.drop(columns=['Obesity'])
y = df['Obesity']

# Display preprocessed dataset
print("Preprocessed Dataset:")
print(df)


# In[75]:


# Initialize MinMaxScaler
scaler = MinMaxScaler()

# Scale numerical features
X_scaled = X.copy()
X_scaled[['age', 'bmi', 'BloodPressure', 'Cholesterol']] = scaler.fit_transform(X_scaled[['age', 'bmi', 'BloodPressure', 'Cholesterol']])

# Display scaled dataset
print("\nScaled Dataset:")
print(X_scaled)


# In[76]:


# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Display training and testing sets
print("\nTraining Set:")
print(X_train, y_train)
print("\nTesting Set:")
print(X_test, y_test)


# In[77]:


#load the result dataset for knn
KNN_results=X_scaled
KNN_results.head()


# # KNN model

# In[79]:


pip install --upgrade scikit-learn


# In[89]:


# Loop through different values of k
for k in range(1, 21):
    # Build and train the model
    ModelKNN = KNeighborsClassifier(n_neighbors=k)
    ModelKNN.fit(X_train, y_train)

    # Predict the model
    y_pred = ModelKNN.predict(X_test)
    y_pred_prob = ModelKNN.predict_proba(X_test)[:, 1]

    print('KNN_K_value = ', k)
    print('Model Name: ', ModelKNN)

    # Confusion matrix
    matrix = confusion_matrix(y_test, y_pred)
    print('Confusion matrix : \n', matrix)

    tp, fn, fp, tn = confusion_matrix(y_test, y_pred).ravel()
    print('Outcome values : \n', tp, fn, fp, tn)

    # Classification report
    C_Report = classification_report(y_test, y_pred)
    print('Classification report : \n', C_Report)

    # Calculate metrics
    sensitivity = round(tp / (tp + fn), 3)
    specificity = round(tn / (tn + fp), 3)
    accuracy_value = round((tp + tn) / (tp + fp + tn + fn), 3)
    balanced_accuracy = round((sensitivity + specificity) / 2, 3)
    precision = round(tp / (tp + fp), 3)
    f1Score = round((2 * tp) / (2 * tp + fp + fn), 3)

    mx = (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    MCC = round(((tp * tn) - (fp * fn)) / sqrt(mx), 3)

    print('Accuracy :', round(accuracy_value * 100, 2), '%')
    print('Precision :', round(precision * 100, 2), '%')
    print('Recall :', round(sensitivity * 100, 2), '%')
    print('F1 Score :', f1Score)
    print('Specificity or True Negative Rate :', round(specificity * 100, 2), '%')
    print('Balanced Accuracy :', round(balanced_accuracy * 100, 2), '%')
    print('MCC :', MCC)

    # ROC AUC score
    roc_auc = round(roc_auc_score(y_test, y_pred_prob), 3)
    print('roc_auc_score:', roc_auc)

    # ROC Curve
    fpr, tpr, thresholds = roc_curve(y_test, y_pred_prob, pos_label=1)  # Specify pos_label=1
    plt.figure()
    plt.plot(fpr, tpr, label=f'KNN (k={k}, AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'r--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    plt.show()

    # Append results
    new_row = {
        'Model Name': 'KNN',
        'KNN K Value': k,
        'True_Positive': tp,
        'False_Negative': fn,
        'False_Positive': fp,
        'True_Negative': tn,
        'Accuracy': accuracy_value,
        'Precision': precision,
        'Recall': sensitivity,
        'F1 Score': f1Score,
        'Specificity': specificity,
        'MCC': MCC,
        'ROC_AUC_Score': roc_auc,
        'Balanced Accuracy': balanced_accuracy
    }
    KNN_results.append(new_row)

# Convert the list to a DataFrame
KNN_results_df = pd.DataFrame(KNN_results)

print(KNN_results_df)


# In[ ]:




